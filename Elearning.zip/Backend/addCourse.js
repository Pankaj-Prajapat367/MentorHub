import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import { v4 as uuidv4 } from "uuid";

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "ap-south-1" });

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
};

export const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  try {
    const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body || {};
    const { title, description, teacher, category, price, thumbnail, level, lessons } = body;

    if (!title || !teacher) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ message: "Missing required fields: title and teacher" }),
      };
    }

    const course_id = body.course_id || uuidv4();

    const command = new PutItemCommand({
      TableName: process.env.COURSES_TABLE || "Courses",
      Item: {
        course_id: { S: course_id },
        title: { S: title },
        description: { S: description || "" },
        teacher: { S: teacher },
        category: { S: category || "Web Development" },
        level: { S: level || "All Levels" },
        price: { N: String(price || 49.99) },
        thumbnail: { S: thumbnail || "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800" },
        created_at: { S: new Date().toISOString() }
      },
    });

    await client.send(command);

    return {
      statusCode: 201,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        message: "Course added successfully",
        course_id,
        course: { course_id, title, description, teacher, category, price, thumbnail }
      }),
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: "Server error", error: err.message }),
    };
  }
};
