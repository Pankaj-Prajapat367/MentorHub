import subprocess
import re
import time
import os

project_dir = os.path.dirname(os.path.abspath(__file__))
url_file = os.path.join(project_dir, 'LIVE_URL.txt')

print("Starting Serveo Auto-Reconnector Tunnel Daemon...")

while True:
    try:
        cmd = [
            'ssh',
            '-R', '80:127.0.0.1:3000',
            '-o', 'StrictHostKeyChecking=no',
            '-o', 'ServerAliveInterval=15',
            '-o', 'ServerAliveCountMax=3',
            'serveo.net'
        ]
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )

        for line in proc.stdout:
            print(line, end='', flush=True)
            match = re.search(r'https://[a-zA-Z0-9\.\-]+\.serveousercontent\.com', line)
            if match:
                url = match.group(0)
                with open(url_file, 'w', encoding='utf-8') as f:
                    f.write(url.strip())
                print(f"\n[TUNNEL READY] Active Live URL saved to LIVE_URL.txt: {url}\n", flush=True)

        proc.wait()
        print("\nServeo session ended. Reconnecting in 2 seconds...", flush=True)
        time.sleep(2)
    except Exception as e:
        print(f"Tunnel error: {e}. Retrying in 5 seconds...", flush=True)
        time.sleep(5)
