const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data', 'db.json');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve all static files from root directory
app.use(express.static(path.join(__dirname)));

// Ensure data folder and db.json exist
function getDb() {
  try {
    if (!fs.existsSync(path.dirname(DB_FILE))) {
      fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    }
    if (!fs.existsSync(DB_FILE)) {
      const initialDb = {
        courses: [
          {
            course_id: "c101",
            title: "Full Stack MERN Mastery: Zero to Production",
            teacher: "John Doe",
            category: "Web Development",
            level: "Intermediate",
            price: 49.99,
            originalPrice: 99.99,
            rating: 4.9,
            ratingCount: 312,
            studentsCount: 1420,
            duration: "24 hours",
            thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&auto=format&fit=crop&q=80",
            description: "Master React 18, Node.js, Express, and MongoDB by building 3 real-world fullstack SaaS platforms with JWT authentication, Redux Toolkit, and Stripe payments.",
            whatYouWillLearn: [
              "Build modern SPAs with React, Hooks, Context, and Redux Toolkit",
              "Design scalable RESTful APIs with Node.js and Express",
              "Schema modeling, aggregation pipelines, and indexing in MongoDB",
              "Production deployment with Docker, Nginx, and cloud hosting"
            ],
            lessons: [
              { id: "l1", title: "Welcome & Course Architecture Overview", duration: "12:40", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l2", title: "React 18 Essentials & Modern Hooks", duration: "24:15", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l3", title: "Building REST APIs with Express & Node", duration: "31:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l4", title: "MongoDB Schema Design & Mongoose Modeling", duration: "28:20", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l5", title: "JWT Authentication & Secure Password Hashing", duration: "22:50", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l6", title: "End-to-End Deployment & Performance Tuning", duration: "35:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
            ]
          },
          {
            course_id: "c102",
            title: "AWS Cloud Architect & Serverless DynamoDB",
            teacher: "Sarah Jenkins",
            category: "Cloud & DevOps",
            level: "Advanced",
            price: 59.99,
            originalPrice: 119.99,
            rating: 4.8,
            ratingCount: 198,
            studentsCount: 890,
            duration: "18 hours",
            thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
            description: "Learn to design highly available, fault-tolerant cloud architectures using AWS Lambda, DynamoDB, API Gateway, S3, and CloudFront. Prepare for the Solutions Architect exam.",
            whatYouWillLearn: [
              "Serverless computing patterns with AWS Lambda & Node.js",
              "DynamoDB single-table design and partition key optimization",
              "Securing APIs with AWS Cognito and API Gateway authorizers",
              "Infrastructure as Code using AWS CDK and Terraform"
            ],
            lessons: [
              { id: "l1", title: "AWS Core Services & High Availability Architecture", duration: "18:30", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l2", title: "Serverless Microservices with AWS Lambda", duration: "25:40", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l3", title: "DynamoDB Modeling, Queries, and Global Secondary Indexes", duration: "34:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l4", title: "API Gateway Integration & CORS Configuration", duration: "20:15", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l5", title: "CloudFront CDN & S3 Static Website Hosting", duration: "16:45", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
            ]
          },
          {
            course_id: "c103",
            title: "Python for Data Science, AI & Machine Learning",
            teacher: "Dr. Alex Rivera",
            category: "AI & Machine Learning",
            level: "Beginner",
            price: 69.99,
            originalPrice: 139.99,
            rating: 4.95,
            ratingCount: 485,
            studentsCount: 2310,
            duration: "32 hours",
            thumbnail: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?w=800&auto=format&fit=crop&q=80",
            description: "From Python programming fundamentals to training Deep Neural Networks with PyTorch, Scikit-learn, and Pandas. Includes LLM prompt engineering and LangChain agents.",
            whatYouWillLearn: [
              "Data manipulation & visualization with Pandas, NumPy, and Seaborn",
              "Supervised & unsupervised machine learning algorithms",
              "Deep Learning with PyTorch and convolutional neural networks",
              "Building Generative AI applications with Gemini and OpenAI APIs"
            ],
            lessons: [
              { id: "l1", title: "Python Data Structures & NumPy Vectorization", duration: "21:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l2", title: "Exploratory Data Analysis with Pandas", duration: "32:15", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l3", title: "Regression & Classification with Scikit-Learn", duration: "40:20", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l4", title: "Neural Networks Fundamentals in PyTorch", duration: "38:45", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
              { id: "l5", title: "Building Autonomous AI Agents with LangChain", duration: "29:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
            ]
          }
        ],
        enrollments: [
          { enrollment_id: "enr_1", student_email: "student@mentorhub.com", course_id: "c101", enrolled_at: "2025-10-10T14:30:00.000Z" },
          { enrollment_id: "enr_2", student_email: "student@mentorhub.com", course_id: "c102", enrolled_at: "2025-10-15T09:12:00.000Z" },
          { enrollment_id: "enr_3", student_email: "alex@code.io", course_id: "c103", enrolled_at: "2025-11-01T18:40:00.000Z" }
        ],
        payments: [
          {
            transaction_id: "TXN-PP-98214",
            student_email: "student@mentorhub.com",
            course_id: "c101",
            course_title: "Full Stack MERN Mastery: Zero to Production",
            amount: 49.99,
            method: "PayPal",
            status: "Completed",
            date: "2025-10-10T14:30:00.000Z"
          },
          {
            transaction_id: "TXN-CC-44812",
            student_email: "student@mentorhub.com",
            course_id: "c102",
            course_title: "AWS Cloud Architect & Serverless DynamoDB",
            amount: 59.99,
            method: "Credit Card",
            status: "Completed",
            date: "2025-10-15T09:12:00.000Z"
          }
        ]
      };
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2));
      return initialDb;
    }
    const data = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error("Database read error:", err);
    return { courses: [], enrollments: [], payments: [] };
  }
}

function saveDb(db) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
    return true;
  } catch (err) {
    console.error("Database save error:", err);
    return false;
  }
}

// REST Endpoints
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'MentorHub LMS API', timestamp: new Date() });
});

// GET /api/courses
app.get('/api/courses', (req, res) => {
  const db = getDb();
  res.json(db.courses);
});

// GET /api/courses/:id
app.get('/api/courses/:id', (req, res) => {
  const db = getDb();
  const course = db.courses.find(c => c.course_id === req.params.id);
  if (!course) return res.status(404).json({ message: 'Course not found' });
  res.json(course);
});

// POST /api/courses (Add course)
app.post('/api/courses', (req, res) => {
  const { title, teacher, description, price, category, thumbnail, level, lessons, whatYouWillLearn } = req.body;
  if (!title || !teacher) {
    return res.status(400).json({ message: 'Title and teacher are required' });
  }

  const db = getDb();
  const newCourse = {
    course_id: req.body.course_id || 'c_' + uuidv4().substring(0, 8),
    title,
    teacher,
    description: description || '',
    category: category || 'Web Development',
    level: level || 'All Levels',
    price: parseFloat(price) || 49.99,
    originalPrice: price ? (parseFloat(price) * 1.5).toFixed(2) : 99.99,
    rating: 5.0,
    ratingCount: 1,
    studentsCount: 0,
    duration: req.body.duration || '10 hours',
    thumbnail: thumbnail || 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&auto=format&fit=crop&q=80',
    whatYouWillLearn: whatYouWillLearn || ['Comprehensive concepts', 'Practical code examples'],
    lessons: lessons || [
      { id: 'l1', title: 'Welcome & Course Intro', duration: '10:00', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' },
      { id: 'l2', title: 'Hands-on Fundamentals', duration: '20:00', videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4' }
    ]
  };

  db.courses.unshift(newCourse);
  saveDb(db);
  res.status(201).json({ message: 'Course created successfully', course: newCourse });
});

// PUT /api/courses/:id
app.put('/api/courses/:id', (req, res) => {
  const db = getDb();
  const index = db.courses.findIndex(c => c.course_id === req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Course not found' });

  db.courses[index] = { ...db.courses[index], ...req.body };
  saveDb(db);
  res.json({ message: 'Course updated', course: db.courses[index] });
});

// DELETE /api/courses/:id
app.delete('/api/courses/:id', (req, res) => {
  const db = getDb();
  db.courses = db.courses.filter(c => c.course_id !== req.params.id);
  saveDb(db);
  res.json({ message: 'Course deleted successfully' });
});

// POST /api/enroll
app.post('/api/enroll', (req, res) => {
  const { student_email, course_id } = req.body;
  if (!student_email || !course_id) {
    return res.status(400).json({ message: 'Missing student_email or course_id' });
  }

  const db = getDb();
  const existing = db.enrollments.find(e => e.student_email === student_email && e.course_id === course_id);
  if (existing) {
    return res.json({ message: 'Student already enrolled', enrollment_id: existing.enrollment_id });
  }

  const enrollment_id = 'enr_' + uuidv4().substring(0, 8);
  const newEnrollment = {
    enrollment_id,
    student_email: student_email.toLowerCase().trim(),
    course_id,
    enrolled_at: new Date().toISOString()
  };

  db.enrollments.push(newEnrollment);

  // Update students count
  const course = db.courses.find(c => c.course_id === course_id);
  if (course) {
    course.studentsCount = (course.studentsCount || 0) + 1;
  }

  saveDb(db);
  res.status(201).json({ message: 'Enrolled successfully', enrollment_id });
});

// GET /api/enrolled-courses
app.get('/api/enrolled-courses', (req, res) => {
  const { student_email } = req.query;
  if (!student_email) return res.status(400).json({ message: 'Missing student_email' });

  const db = getDb();
  const enrolled = db.enrollments.filter(e => e.student_email === student_email.toLowerCase().trim());
  res.json(enrolled);
});

// GET /api/enrollments
app.get('/api/enrollments', (req, res) => {
  const db = getDb();
  res.json(db.enrollments);
});

// POST /api/payments
app.post('/api/payments', (req, res) => {
  const { student_email, course_id, amount, method, course_title } = req.body;
  const db = getDb();

  const txn = {
    transaction_id: req.body.transaction_id || ('TXN-' + uuidv4().substring(0, 8).toUpperCase()),
    student_email: student_email ? student_email.toLowerCase().trim() : 'student@mentorhub.com',
    course_id,
    course_title: course_title || 'Course Enrollment',
    amount: parseFloat(amount) || 49.99,
    method: method || 'PayPal',
    status: 'Completed',
    date: new Date().toISOString()
  };

  db.payments.unshift(txn);

  // Also auto-enroll if not already enrolled
  if (student_email && course_id) {
    const exists = db.enrollments.find(e => e.student_email === txn.student_email && e.course_id === course_id);
    if (!exists) {
      db.enrollments.push({
        enrollment_id: 'enr_' + uuidv4().substring(0, 8),
        student_email: txn.student_email,
        course_id,
        enrolled_at: new Date().toISOString()
      });
      const c = db.courses.find(item => item.course_id === course_id);
      if (c) c.studentsCount = (c.studentsCount || 0) + 1;
    }
  }

  saveDb(db);
  res.status(201).json({ message: 'Payment recorded', transaction: txn });
});

// GET /api/payments
app.get('/api/payments', (req, res) => {
  const db = getDb();
  res.json(db.payments);
});

// GET /api/stats
app.get('/api/stats', (req, res) => {
  const db = getDb();
  const totalCourses = db.courses.length;
  const totalEnrollments = db.enrollments.length;
  const totalRevenue = db.payments.reduce((sum, p) => sum + (parseFloat(p.amount) || 0), 0);
  const teachers = new Set(db.courses.map(c => c.teacher));

  res.json({
    totalCourses,
    totalEnrollments,
    totalRevenue: parseFloat(totalRevenue.toFixed(2)),
    totalInstructors: teachers.size
  });
});

// Default route fallback to landing.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'landing.html'));
});

app.listen(PORT, () => {
  console.log(`MentorHub LMS server is running at http://localhost:${PORT}`);
});
