import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import { v4 as uuidv4 } from "uuid";

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "ap-south-1" });

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
};

export const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  try {
    const body = typeof event.body === "string" ? JSON.parse(event.body) : event.body || {};
    const { student_email, course_id } = body;

    if (!student_email || !course_id) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ message: "Missing required fields: student_email and course_id" }),
      };
    }

    const enrollment_id = uuidv4();

    const command = new PutItemCommand({
      TableName: process.env.ENROLLMENTS_TABLE || "Enrollments",
      Item: {
        enrollment_id: { S: enrollment_id },
        student_email: { S: student_email.toLowerCase().trim() },
        course_id: { S: course_id },
        enrolled_at: { S: new Date().toISOString() }
      },
    });

    await client.send(command);

    return {
      statusCode: 201,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: "Student enrolled successfully", enrollment_id }),
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: "Server error", error: err.message }),
    };
  }
};
