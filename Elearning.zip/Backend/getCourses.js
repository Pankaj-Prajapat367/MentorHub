import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "ap-south-1" });

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
};

export const handler = async (event) => {
  if (event && event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  try {
    const command = new ScanCommand({ TableName: process.env.COURSES_TABLE || "Courses" });
    const result = await client.send(command);

    const courses = (result.Items || []).map((item) => ({
      course_id: item.course_id?.S || "",
      title: item.title?.S || "Untitled Course",
      description: item.description?.S || "",
      teacher: item.teacher?.S || "Instructor",
      category: item.category?.S || "General",
      level: item.level?.S || "All Levels",
      price: item.price?.N ? parseFloat(item.price.N) : 49.99,
      thumbnail: item.thumbnail?.S || "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800",
      rating: 4.9,
      studentsCount: 100
    }));

    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify(courses),
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: "Error fetching courses", error: err.message }),
    };
  }
};
