import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "ap-south-1" });

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET,PUT,DELETE"
};

export const handler = async (event) => {
  if (event && event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }

  try {
    const student_email = (event.queryStringParameters?.student_email || "").toLowerCase().trim();

    if (!student_email) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({ message: "Missing required query parameter: student_email" }),
      };
    }

    const command = new ScanCommand({ TableName: process.env.ENROLLMENTS_TABLE || "Enrollments" });
    const result = await client.send(command);

    const enrolled = (result.Items || [])
      .filter((item) => item.student_email?.S?.toLowerCase() === student_email)
      .map((item) => ({
        enrollment_id: item.enrollment_id?.S || "",
        course_id: item.course_id?.S || "",
        enrolled_at: item.enrolled_at?.S || new Date().toISOString()
      }));

    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify(enrolled),
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ message: "Error fetching enrollments", error: err.message }),
    };
  }
};
