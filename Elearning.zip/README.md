# MentorHub LMS 🚀
> A Modern, Full-Stack Learning Management System (LMS) with Course Authoring, Student Classroom, Interactive Video Player, Progress Tracking, Certifications, and Seamless Payments.

---

## 🌐 Live Deployment & Links

- **Active Live Public URL**: [https://5d9488efbb72cfa4-157-48-253-153.serveousercontent.com](https://5d9488efbb72cfa4-157-48-253-153.serveousercontent.com)
- **Local Dev Server**: [http://localhost:3000](http://localhost:3000)
- **Primary Pages**:
  - **Home / Landing**: `/landing.html` or `/`
  - **Courses Catalog**: `/courses.html`
  - **Instructor Studio**: `/instructor.html`
  - **Student Portal**: `/student.html`
  - **Payments & Checkout**: `/payments.html`

---

## 🎯 Architecture & What Was Built

The project was transformed from empty static placeholder cards into a production-grade, interactive LMS with dual architecture:

### 1. Unified Dual Data Layer (`js/api.js`)
- **Node.js Express REST Backend Mode**: Automatically connects to the local or cloud backend API endpoints (`/api/*`).
- **Browser Persistence Fallback Mode**: When deployed to static hosts (e.g. Vercel, Netlify, GitHub Pages, Surge) without a Node server, the frontend automatically falls back to an enriched persistent `localStorage` store with zero errors or degraded functionality.

### 2. Functional Modules

#### 📚 Course Discovery (`courses.html`)
- **Live Catalog**: Browse courses with category filtering (Web Dev, Cloud & DevOps, AI/ML, Design, Security).
- **Search & Sort**: Instant search by title, instructor, or keywords; sort by popularity, rating, and price.
- **Interactive Syllabus Modal**: Preview curriculum modules, duration, and learning outcomes before enrolling.
- **Smart Enrollment Status**: Shows "Enrolled ✓ (Continue Learning)" if the logged-in student has already enrolled.

#### 👩‍🏫 Instructor Studio (`instructor.html`)
- **Course Authoring**: Create new courses with title, category, difficulty, pricing, description, thumbnail presets, and dynamically added syllabus lessons.
- **Course Management**: Edit course metadata or delete courses with real-time UI synchronization.
- **Student Analytics**: View all enrolled learners across courses with enrollment timestamps.
- **Revenue Tracking**: Live earnings breakdown from platform sales.

#### 🎓 Student Classroom & Portal (`student.html`)
- **Enrolled Courses**: View all courses the student is enrolled in with visual progress bars.
- **Interactive Classroom Player**:
  - Embedded video player with responsive controls.
  - Interactive syllabus checklist: mark lessons as complete to advance overall progress.
  - Objectives and takeaways notes panel.
- **Official Certificate Generator**:
  - Awarded upon reaching 100% completion.
  - Beautiful gold-bordered certificate featuring student name, course title, instructor signature, completion date, and credential ID.
  - One-click print/download to PDF.

#### 💳 Payments & Checkout (`payments.html`)
- **Seamless Gateway Checkout**: Supports PayPal, Credit/Debit Card (with mock validation), and Instant Sandbox mode.
- **Dynamic Order Summary**: Auto-calculates tax, discounts, and totals.
- **Coupon Code Engine**: Apply promo codes (e.g. `MENTOR20` for 20% off!).
- **Instant Verified Receipt**: Transaction ID, payment method, student email, and direct link to classroom.
- **Platform Ledger**: Searchable history of all platform transactions.

#### ⚡ REST API Endpoints (`server.js`)
- `GET /api/health` - API health status
- `GET /api/courses` - Fetch all courses
- `POST /api/courses` - Create new course
- `PUT /api/courses/:id` - Update existing course
- `DELETE /api/courses/:id` - Delete course
- `POST /api/enroll` - Enroll a student in a course
- `GET /api/enrolled-courses?student_email=...` - Fetch enrollments for a student
- `GET /api/enrollments` - Fetch all platform enrollments
- `POST /api/payments` - Process payment & auto-enroll student
- `GET /api/payments` - Fetch platform transaction history
- `GET /api/stats` - Platform aggregate statistics

#### ☁️ AWS Lambda & DynamoDB Handlers (`Backend/` & `addCourseLambda/`)
- Updated with standard CORS headers (`*`) and extended fields (`category`, `price`, `thumbnail`, `lessons`) for users wishing to deploy serverless on AWS API Gateway and DynamoDB tables (`Courses` and `Enrollments`).

---

## 🚀 Running Locally

1. **Clone or Navigate to the Directory**:
   ```bash
   cd "C:\Users\91810\.gemini\antigravity\scratch\instructor"
   ```

2. **Install Dependencies**:
   ```bash
   npm install
   ```

3. **Start the Application**:
   ```bash
   npm start
   ```

4. Open [http://localhost:3000](http://localhost:3000) in your browser!

---

## 🛠️ Deploying to the Cloud

### Option A: Vercel / Netlify / Render (Static or Serverless)
1. Push this directory to a GitHub repository.
2. Import the repository into [Vercel](https://vercel.com) or [Netlify](https://netlify.com).
3. The root `index.html` and `server.js` will be auto-detected.

### Option B: AWS Lambda + DynamoDB
1. Create DynamoDB tables `Courses` (Partition key: `course_id` (String)) and `Enrollments` (Partition key: `enrollment_id` (String)).
2. Zip the handlers in `Backend/` and deploy to AWS Lambda with an HTTP API Gateway trigger.
