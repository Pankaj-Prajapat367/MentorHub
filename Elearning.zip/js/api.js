/**
 * MentorHub LMS - Unified Data & API Layer
 * Seamlessly interfaces with Node.js Express backend when available,
 * and automatically falls back to browser-persistent LocalStorage when deployed statically.
 */

const SEED_COURSES = [
  {
    course_id: "c101",
    title: "Full Stack MERN Mastery: Zero to Production",
    teacher: "John Doe",
    category: "Web Development",
    level: "Intermediate",
    price: 49.99,
    originalPrice: 99.99,
    rating: 4.9,
    ratingCount: 312,
    studentsCount: 1420,
    duration: "24 hours",
    thumbnail: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=800&auto=format&fit=crop&q=80",
    description: "Master React 18, Node.js, Express, and MongoDB by building 3 real-world fullstack SaaS platforms with JWT authentication, Redux Toolkit, and Stripe payments.",
    whatYouWillLearn: [
      "Build modern SPAs with React, Hooks, Context, and Redux Toolkit",
      "Design scalable RESTful APIs with Node.js and Express",
      "Schema modeling, aggregation pipelines, and indexing in MongoDB",
      "Production deployment with Docker, Nginx, and cloud hosting"
    ],
    lessons: [
      { id: "l1", title: "Welcome & Course Architecture Overview", duration: "12:40", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l2", title: "React 18 Essentials & Modern Hooks", duration: "24:15", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l3", title: "Building REST APIs with Express & Node", duration: "31:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l4", title: "MongoDB Schema Design & Mongoose Modeling", duration: "28:20", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l5", title: "JWT Authentication & Secure Password Hashing", duration: "22:50", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l6", title: "End-to-End Deployment & Performance Tuning", duration: "35:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
    ]
  },
  {
    course_id: "c102",
    title: "AWS Cloud Architect & Serverless DynamoDB",
    teacher: "Sarah Jenkins",
    category: "Cloud & DevOps",
    level: "Advanced",
    price: 59.99,
    originalPrice: 119.99,
    rating: 4.8,
    ratingCount: 198,
    studentsCount: 890,
    duration: "18 hours",
    thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
    description: "Learn to design highly available, fault-tolerant cloud architectures using AWS Lambda, DynamoDB, API Gateway, S3, and CloudFront. Prepare for the Solutions Architect exam.",
    whatYouWillLearn: [
      "Serverless computing patterns with AWS Lambda & Node.js",
      "DynamoDB single-table design and partition key optimization",
      "Securing APIs with AWS Cognito and API Gateway authorizers",
      "Infrastructure as Code using AWS CDK and Terraform"
    ],
    lessons: [
      { id: "l1", title: "AWS Core Services & High Availability Architecture", duration: "18:30", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l2", title: "Serverless Microservices with AWS Lambda", duration: "25:40", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l3", title: "DynamoDB Modeling, Queries, and Global Secondary Indexes", duration: "34:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l4", title: "API Gateway Integration & CORS Configuration", duration: "20:15", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l5", title: "CloudFront CDN & S3 Static Website Hosting", duration: "16:45", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
    ]
  },
  {
    course_id: "c103",
    title: "Python for Data Science, AI & Machine Learning",
    teacher: "Dr. Alex Rivera",
    category: "AI & Machine Learning",
    level: "Beginner",
    price: 69.99,
    originalPrice: 139.99,
    rating: 4.95,
    ratingCount: 485,
    studentsCount: 2310,
    duration: "32 hours",
    thumbnail: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?w=800&auto=format&fit=crop&q=80",
    description: "From Python programming fundamentals to training Deep Neural Networks with PyTorch, Scikit-learn, and Pandas. Includes LLM prompt engineering and LangChain agents.",
    whatYouWillLearn: [
      "Data manipulation & visualization with Pandas, NumPy, and Seaborn",
      "Supervised & unsupervised machine learning algorithms",
      "Deep Learning with PyTorch and convolutional neural networks",
      "Building Generative AI applications with Gemini and OpenAI APIs"
    ],
    lessons: [
      { id: "l1", title: "Python Data Structures & NumPy Vectorization", duration: "21:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l2", title: "Exploratory Data Analysis with Pandas", duration: "32:15", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l3", title: "Regression & Classification with Scikit-Learn", duration: "40:20", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l4", title: "Neural Networks Fundamentals in PyTorch", duration: "38:45", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l5", title: "Building Autonomous AI Agents with LangChain", duration: "29:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
    ]
  },
  {
    course_id: "c104",
    title: "Modern Next.js 14 & Tailwind CSS Masterclass",
    teacher: "Brad Traversy",
    category: "Web Development",
    level: "Intermediate",
    price: 39.99,
    originalPrice: 79.99,
    rating: 4.75,
    ratingCount: 140,
    studentsCount: 760,
    duration: "14 hours",
    thumbnail: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800&auto=format&fit=crop&q=80",
    description: "Harness the power of React Server Components, Server Actions, App Router, and Tailwind CSS. Build high-speed full-stack websites with optimal SEO performance.",
    whatYouWillLearn: [
      "Next.js 14 App Router vs Pages Router architecture",
      "Server Components, Client Components, and Streaming SSR",
      "Building forms with Server Actions and Zod validation",
      "Styling with Tailwind CSS, Shadcn UI, and dark mode"
    ],
    lessons: [
      { id: "l1", title: "Next.js 14 Setup & App Router Deep Dive", duration: "19:40", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l2", title: "Tailwind CSS Layouts & Responsive Design", duration: "26:30", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l3", title: "Server Actions and Database Mutations", duration: "22:15", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l4", title: "Authentication with NextAuth & Middleware", duration: "30:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
    ]
  },
  {
    course_id: "c105",
    title: "UI/UX Design Systems & Prototyping in Figma",
    teacher: "Elena Rostova",
    category: "Design",
    level: "Beginner",
    price: 29.99,
    originalPrice: 69.99,
    rating: 4.9,
    ratingCount: 220,
    studentsCount: 1150,
    duration: "11 hours",
    thumbnail: "https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=800&auto=format&fit=crop&q=80",
    description: "Create scalable design systems, auto-layouts, responsive component libraries, and interactive micro-animations that seamlessly hand off to developers.",
    whatYouWillLearn: [
      "Design tokens, color styles, and typographic scales",
      "Advanced Auto-Layout and responsive component variants",
      "High-fidelity prototyping with interactive micro-animations",
      "Developer handoff workflows and design documentation"
    ],
    lessons: [
      { id: "l1", title: "Principles of Modern UI/UX Architecture", duration: "16:20", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l2", title: "Mastering Figma Auto-Layout & Constraints", duration: "28:50", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l3", title: "Building a Production Design System", duration: "35:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l4", title: "Interactive Prototyping & Smart Animate", duration: "21:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
    ]
  },
  {
    course_id: "c106",
    title: "Practical Ethical Hacking & Web Security",
    teacher: "Marcus Vance",
    category: "Security",
    level: "Intermediate",
    price: 54.99,
    originalPrice: 109.99,
    rating: 4.85,
    ratingCount: 175,
    studentsCount: 640,
    duration: "16 hours",
    thumbnail: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&auto=format&fit=crop&q=80",
    description: "Hands-on penetration testing and defensive engineering. Understand OWASP Top 10 vulnerabilities, SQL injection, XSS, and CSRF protection techniques.",
    whatYouWillLearn: [
      "Penetration testing methodologies and reconnaissance",
      "Deep dive into OWASP Top 10 vulnerabilities",
      "Defensive coding practices for Node.js and web applications",
      "API penetration testing and token authorization flaws"
    ],
    lessons: [
      { id: "l1", title: "Ethical Hacking Lab Setup & Networking Basics", duration: "18:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l2", title: "Cross-Site Scripting (XSS) Attack & Defense", duration: "27:30", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l3", title: "SQL Injection and Parameterized Queries", duration: "33:10", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
      { id: "l4", title: "Securing Node.js Applications with Helmet & CORS", duration: "20:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
    ]
  }
];

const SEED_ENROLLMENTS = [
  { enrollment_id: "enr_1", student_email: "student@mentorhub.com", course_id: "c101", enrolled_at: "2025-10-10T14:30:00.000Z" },
  { enrollment_id: "enr_2", student_email: "student@mentorhub.com", course_id: "c102", enrolled_at: "2025-10-15T09:12:00.000Z" },
  { enrollment_id: "enr_3", student_email: "alex@code.io", course_id: "c103", enrolled_at: "2025-11-01T18:40:00.000Z" }
];

const SEED_PAYMENTS = [
  {
    transaction_id: "TXN-PP-98214",
    student_email: "student@mentorhub.com",
    course_id: "c101",
    course_title: "Full Stack MERN Mastery: Zero to Production",
    amount: 49.99,
    method: "PayPal",
    status: "Completed",
    date: "2025-10-10T14:30:00.000Z"
  },
  {
    transaction_id: "TXN-CC-44812",
    student_email: "student@mentorhub.com",
    course_id: "c102",
    course_title: "AWS Cloud Architect & Serverless DynamoDB",
    amount: 59.99,
    method: "Credit Card",
    status: "Completed",
    date: "2025-10-15T09:12:00.000Z"
  },
  {
    transaction_id: "TXN-PP-11920",
    student_email: "alex@code.io",
    course_id: "c103",
    course_title: "Python for Data Science, AI & Machine Learning",
    amount: 69.99,
    method: "PayPal",
    status: "Completed",
    date: "2025-11-01T18:40:00.000Z"
  }
];

const SEED_PROGRESS = {
  "student@mentorhub.com": {
    "c101": ["l1", "l2", "l3"],
    "c102": ["l1"]
  }
};

class LMSApi {
  constructor() {
    this.apiUrl = "/api";
    this.serverOnline = null;
    this.initStorage();
  }

  initStorage() {
    if (!localStorage.getItem("mentorhub_courses")) {
      localStorage.setItem("mentorhub_courses", JSON.stringify(SEED_COURSES));
    }
    if (!localStorage.getItem("mentorhub_enrollments")) {
      localStorage.setItem("mentorhub_enrollments", JSON.stringify(SEED_ENROLLMENTS));
    }
    if (!localStorage.getItem("mentorhub_payments")) {
      localStorage.setItem("mentorhub_payments", JSON.stringify(SEED_PAYMENTS));
    }
    if (!localStorage.getItem("mentorhub_progress")) {
      localStorage.setItem("mentorhub_progress", JSON.stringify(SEED_PROGRESS));
    }
    if (!localStorage.getItem("mentorhub_active_student")) {
      localStorage.setItem("mentorhub_active_student", "student@mentorhub.com");
    }
    if (!localStorage.getItem("mentorhub_active_instructor")) {
      localStorage.setItem("mentorhub_active_instructor", "John Doe");
    }
  }

  async checkServer() {
    if (this.serverOnline !== null) return this.serverOnline;
    try {
      const res = await fetch(`${this.apiUrl}/health`, { method: "GET", cache: "no-store" });
      this.serverOnline = res.ok;
    } catch (e) {
      this.serverOnline = false;
    }
    return this.serverOnline;
  }

  getActiveStudent() {
    return localStorage.getItem("mentorhub_active_student") || "student@mentorhub.com";
  }

  setActiveStudent(email) {
    localStorage.setItem("mentorhub_active_student", email.trim());
    window.dispatchEvent(new CustomEvent("mentorhub_user_changed", { detail: { role: "student", email } }));
  }

  getActiveInstructor() {
    return localStorage.getItem("mentorhub_active_instructor") || "John Doe";
  }

  setActiveInstructor(name) {
    localStorage.setItem("mentorhub_active_instructor", name.trim());
    window.dispatchEvent(new CustomEvent("mentorhub_user_changed", { detail: { role: "instructor", name } }));
  }

  // --- Courses ---
  async getCourses() {
    const isServer = await this.checkServer();
    if (isServer) {
      try {
        const res = await fetch(`${this.apiUrl}/courses`);
        if (res.ok) {
          const courses = await res.json();
          localStorage.setItem("mentorhub_courses", JSON.stringify(courses));
          return courses;
        }
      } catch (err) {
        console.warn("Backend fetch failed, falling back to local store:", err);
      }
    }
    return JSON.parse(localStorage.getItem("mentorhub_courses")) || SEED_COURSES;
  }

  async getCourseById(id) {
    const courses = await this.getCourses();
    return courses.find(c => c.course_id === id) || null;
  }

  async addCourse(course) {
    const newCourse = {
      course_id: "c_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      rating: 5.0,
      ratingCount: 1,
      studentsCount: 0,
      originalPrice: course.price ? (parseFloat(course.price) * 1.5).toFixed(2) : 99.99,
      duration: course.duration || "10 hours",
      whatYouWillLearn: course.whatYouWillLearn || ["Comprehensive syllabus overview", "Hands-on projects and exercises"],
      lessons: course.lessons && course.lessons.length > 0 ? course.lessons : [
        { id: "l1", title: "Introduction & Setup", duration: "10:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
        { id: "l2", title: "Core Concepts & Fundamentals", duration: "25:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" },
        { id: "l3", title: "Building Practical Project", duration: "45:00", videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4" }
      ],
      ...course
    };

    const isServer = await this.checkServer();
    if (isServer) {
      try {
        const res = await fetch(`${this.apiUrl}/courses`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(newCourse)
        });
        if (res.ok) {
          const saved = await res.json();
          const local = JSON.parse(localStorage.getItem("mentorhub_courses")) || [];
          local.unshift(saved.course || newCourse);
          localStorage.setItem("mentorhub_courses", JSON.stringify(local));
          return saved.course || newCourse;
        }
      } catch (e) {
        console.warn("Server POST error, saving locally", e);
      }
    }

    const localCourses = JSON.parse(localStorage.getItem("mentorhub_courses")) || [];
    localCourses.unshift(newCourse);
    localStorage.setItem("mentorhub_courses", JSON.stringify(localCourses));
    return newCourse;
  }

  async updateCourse(id, updatedFields) {
    const isServer = await this.checkServer();
    if (isServer) {
      try {
        const res = await fetch(`${this.apiUrl}/courses/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(updatedFields)
        });
        if (res.ok) {
          const resData = await res.json();
          // Update local cache
          const courses = JSON.parse(localStorage.getItem("mentorhub_courses")) || [];
          const idx = courses.findIndex(c => c.course_id === id);
          if (idx !== -1) {
            courses[idx] = { ...courses[idx], ...updatedFields };
            localStorage.setItem("mentorhub_courses", JSON.stringify(courses));
          }
          return resData.course;
        }
      } catch (e) {
        console.warn("Server PUT error, updating locally", e);
      }
    }

    const courses = JSON.parse(localStorage.getItem("mentorhub_courses")) || [];
    const idx = courses.findIndex(c => c.course_id === id);
    if (idx !== -1) {
      courses[idx] = { ...courses[idx], ...updatedFields };
      localStorage.setItem("mentorhub_courses", JSON.stringify(courses));
      return courses[idx];
    }
    return null;
  }

  async deleteCourse(id) {
    const isServer = await this.checkServer();
    if (isServer) {
      try {
        await fetch(`${this.apiUrl}/courses/${id}`, { method: "DELETE" });
      } catch (e) {
        console.warn("Server DELETE error", e);
      }
    }
    let courses = JSON.parse(localStorage.getItem("mentorhub_courses")) || [];
    courses = courses.filter(c => c.course_id !== id);
    localStorage.setItem("mentorhub_courses", JSON.stringify(courses));
    return true;
  }

  // --- Enrollments ---
  async enrollStudent(studentEmail, courseId) {
    studentEmail = (studentEmail || this.getActiveStudent()).toLowerCase().trim();
    const enrollment = {
      enrollment_id: "enr_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      student_email: studentEmail,
      course_id: courseId,
      enrolled_at: new Date().toISOString()
    };

    const isServer = await this.checkServer();
    if (isServer) {
      try {
        const res = await fetch(`${this.apiUrl}/enroll`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ student_email: studentEmail, course_id: courseId })
        });
        if (res.ok) {
          const data = await res.json();
          enrollment.enrollment_id = data.enrollment_id || enrollment.enrollment_id;
        }
      } catch (e) {
        console.warn("Server enroll error, recording locally", e);
      }
    }

    const enrollments = JSON.parse(localStorage.getItem("mentorhub_enrollments")) || [];
    const exists = enrollments.find(e => e.student_email === studentEmail && e.course_id === courseId);
    if (!exists) {
      enrollments.push(enrollment);
      localStorage.setItem("mentorhub_enrollments", JSON.stringify(enrollments));

      // Increase students count for the course
      const courses = JSON.parse(localStorage.getItem("mentorhub_courses")) || [];
      const course = courses.find(c => c.course_id === courseId);
      if (course) {
        course.studentsCount = (course.studentsCount || 0) + 1;
        localStorage.setItem("mentorhub_courses", JSON.stringify(courses));
      }
    }
    return enrollment;
  }

  async isStudentEnrolled(studentEmail, courseId) {
    studentEmail = (studentEmail || this.getActiveStudent()).toLowerCase().trim();
    const enrollments = JSON.parse(localStorage.getItem("mentorhub_enrollments")) || [];
    return enrollments.some(e => e.student_email === studentEmail && e.course_id === courseId);
  }

  async getEnrolledCourses(studentEmail) {
    studentEmail = (studentEmail || this.getActiveStudent()).toLowerCase().trim();
    const isServer = await this.checkServer();
    let userEnrs = [];

    if (isServer) {
      try {
        const res = await fetch(`${this.apiUrl}/enrolled-courses?student_email=${encodeURIComponent(studentEmail)}`);
        if (res.ok) {
          userEnrs = await res.json();
        }
      } catch (e) {
        console.warn("Server enrollments fetch failed", e);
      }
    }

    if (!userEnrs || userEnrs.length === 0) {
      const enrollments = JSON.parse(localStorage.getItem("mentorhub_enrollments")) || [];
      userEnrs = enrollments.filter(e => e.student_email.toLowerCase() === studentEmail);
    }

    const allCourses = await this.getCourses();
    const enrolledCoursesWithDetails = [];

    for (const enr of userEnrs) {
      const course = allCourses.find(c => c.course_id === enr.course_id);
      if (course) {
        const progress = this.getCourseProgress(studentEmail, course.course_id);
        const totalLessons = (course.lessons && course.lessons.length) || 1;
        const completedCount = progress.completedLessons.length;
        const percentage = Math.round((completedCount / totalLessons) * 100);

        enrolledCoursesWithDetails.push({
          ...course,
          enrollment_id: enr.enrollment_id,
          enrolled_at: enr.enrolled_at || "Recent",
          progressPercentage: percentage,
          completedLessons: progress.completedLessons
        });
      }
    }
    return enrolledCoursesWithDetails;
  }

  async getAllEnrollments() {
    const isServer = await this.checkServer();
    if (isServer) {
      try {
        const res = await fetch(`${this.apiUrl}/enrollments`);
        if (res.ok) return await res.json();
      } catch (e) {}
    }
    return JSON.parse(localStorage.getItem("mentorhub_enrollments")) || [];
  }

  // --- Payments ---
  async processPayment({ studentEmail, courseId, amount, method }) {
    const course = await this.getCourseById(courseId);
    const txn = {
      transaction_id: "TXN-" + (method === "PayPal" ? "PP-" : "CC-") + Math.floor(10000 + Math.random() * 90000),
      student_email: (studentEmail || this.getActiveStudent()).toLowerCase().trim(),
      course_id: courseId,
      course_title: course ? course.title : "LMS Course",
      amount: parseFloat(amount || (course ? course.price : 49.99)),
      method: method || "PayPal",
      status: "Completed",
      date: new Date().toISOString()
    };

    const isServer = await this.checkServer();
    if (isServer) {
      try {
        await fetch(`${this.apiUrl}/payments`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(txn)
        });
      } catch (e) {}
    }

    const payments = JSON.parse(localStorage.getItem("mentorhub_payments")) || [];
    payments.unshift(txn);
    localStorage.setItem("mentorhub_payments", JSON.stringify(payments));

    // Auto-enroll the student
    await this.enrollStudent(txn.student_email, courseId);

    return txn;
  }

  async getPayments() {
    const isServer = await this.checkServer();
    if (isServer) {
      try {
        const res = await fetch(`${this.apiUrl}/payments`);
        if (res.ok) return await res.json();
      } catch (e) {}
    }
    return JSON.parse(localStorage.getItem("mentorhub_payments")) || [];
  }

  // --- Lesson Progress & Certification ---
  getCourseProgress(studentEmail, courseId) {
    studentEmail = (studentEmail || this.getActiveStudent()).toLowerCase().trim();
    const progressStore = JSON.parse(localStorage.getItem("mentorhub_progress")) || {};
    const userProgress = progressStore[studentEmail] || {};
    const completed = userProgress[courseId] || [];
    return {
      completedLessons: completed,
      isCompleted: false // determined when comparing to total lessons
    };
  }

  updateLessonProgress(studentEmail, courseId, lessonId, isCompleted = true) {
    studentEmail = (studentEmail || this.getActiveStudent()).toLowerCase().trim();
    const progressStore = JSON.parse(localStorage.getItem("mentorhub_progress")) || {};
    if (!progressStore[studentEmail]) progressStore[studentEmail] = {};
    if (!progressStore[studentEmail][courseId]) progressStore[studentEmail][courseId] = [];

    const list = progressStore[studentEmail][courseId];
    if (isCompleted && !list.includes(lessonId)) {
      list.push(lessonId);
    } else if (!isCompleted && list.includes(lessonId)) {
      progressStore[studentEmail][courseId] = list.filter(id => id !== lessonId);
    }
    localStorage.setItem("mentorhub_progress", JSON.stringify(progressStore));
    return progressStore[studentEmail][courseId];
  }

  resetAllData() {
    localStorage.removeItem("mentorhub_courses");
    localStorage.removeItem("mentorhub_enrollments");
    localStorage.removeItem("mentorhub_payments");
    localStorage.removeItem("mentorhub_progress");
    this.initStorage();
    return true;
  }
}

// Global UI Toast Utility
function showToast(message, type = "info") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "toast-container";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  const icons = {
    success: "✓",
    error: "✕",
    info: "ℹ"
  };
  toast.innerHTML = `<span style="font-weight: bold; font-size: 1.1rem;">${icons[type] || "•"}</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(10px)";
    toast.style.transition = "all 0.3s ease";
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// Global Navbar Initializer
function renderNavbar(activePage = "home") {
  const navPlaceholder = document.getElementById("navbar-placeholder");
  if (!navPlaceholder) return;

  const activeStudent = window.api ? window.api.getActiveStudent() : "student@mentorhub.com";
  const activeInstructor = window.api ? window.api.getActiveInstructor() : "John Doe";

  navPlaceholder.innerHTML = `
    <nav class="navbar">
      <div class="nav-container">
        <a href="landing.html" class="nav-brand">
          <span>🚀 MentorHub</span>
          <span class="badge-tag">LMS</span>
        </a>

        <ul class="nav-links">
          <li><a href="landing.html" class="${activePage === 'home' ? 'active' : ''}">🏠 Home</a></li>
          <li><a href="courses.html" class="${activePage === 'courses' ? 'active' : ''}">📚 Courses</a></li>
          <li><a href="instructor.html" class="${activePage === 'instructor' ? 'active' : ''}">👩‍🏫 Instructor</a></li>
          <li><a href="student.html" class="${activePage === 'student' ? 'active' : ''}">🎓 Student Portal</a></li>
          <li><a href="payments.html" class="${activePage === 'payments' ? 'active' : ''}">💳 Payments</a></li>
        </ul>

        <div class="nav-right">
          <div class="role-badge" title="Active student session">
            <span class="sync-status"></span>
            <span>🎓 ${activeStudent.split('@')[0]}</span>
          </div>
          <button id="btn-quick-switch" class="btn btn-outline btn-sm" title="Quick switch active user profile">⚙ Switch User</button>
        </div>
      </div>
    </nav>
  `;

  // Quick switch user modal trigger
  const btnSwitch = document.getElementById("btn-quick-switch");
  if (btnSwitch) {
    btnSwitch.addEventListener("click", () => {
      promptUserSwitch();
    });
  }
}

function promptUserSwitch() {
  const current = window.api.getActiveStudent();
  const newEmail = prompt("Switch Student Email:", current);
  if (newEmail && newEmail.trim() && newEmail.includes("@")) {
    window.api.setActiveStudent(newEmail.trim());
    showToast(`Switched active student to ${newEmail.trim()}`, "success");
    setTimeout(() => location.reload(), 600);
  }
}

// Global API instance
window.api = new LMSApi();
